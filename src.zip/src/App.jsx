import React from "react";
import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";

import HomePage from "./Pages/HomePage/HomePage";
import LoginPage from "./Pages/UserLogin/LoginPage";
import SignupPage from "./Pages/UserSignupPage/SignupPage";
import UserDashboard from "./Pages/UserDashboard/DashboardPage";

import ProtectedRoute from "./Components/ProtectedRoute";

function App() {
  return (
    <BrowserRouter>

      <Routes>

        {/* HOME */}
        <Route
          path="/"
          element={<HomePage />}
        />

        {/* LOGIN */}
        <Route
          path="/login"
          element={<LoginPage />}
        />

        {/* SIGNUP */}
        <Route
          path="/signup"
          element={<SignupPage />}
        />

        {/* PROTECTED DASHBOARD */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <UserDashboard />
            </ProtectedRoute>
          }
        />

      </Routes>

    </BrowserRouter>
  );
}

export default App;