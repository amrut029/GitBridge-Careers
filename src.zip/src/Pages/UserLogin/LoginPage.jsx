import React, { useState } from "react";
import "./LoginPage.css";

import {
  googleLogin,
  emailLogin,
} from "../../Services/authService";

import { useNavigate } from "react-router-dom";

const LoginPage = () => {

  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [loading, setLoading] = useState(false);


  // =========================
  // EMAIL LOGIN
  // =========================
  const handleEmailLogin = async (e) => {

    e.preventDefault();

    if (!email || !password) {
      alert("Please enter email and password.");
      return;
    }

    try {

      setLoading(true);

      // Firebase login
      await emailLogin(
        email,
        password
      );

      // Login successful
      navigate("/dashboard");

    } catch (error) {

      console.error(error);

      alert(
        error.message ||
        "Login failed. Please check your credentials."
      );

    } finally {

      setLoading(false);

    }
  };


  // =========================
  // GOOGLE LOGIN
  // =========================
  const handleGoogleLogin = async () => {

    try {

      setLoading(true);

      // Firebase Google Login
      await googleLogin();

      // Login successful
      navigate("/dashboard");

    } catch (error) {

      console.error(error);

      if (
        error.code !==
        "auth/cancelled-popup-request"
      ) {

        alert(
          error.message ||
          "Google login failed."
        );

      }

    } finally {

      setLoading(false);

    }
  };


  return (

    <div className="login-page">

      {/* =========================
          BACK BUTTON
      ========================= */}

      <button
        className="back-home"
        onClick={() => navigate("/")}
      >
        ← Back to Home
      </button>


      <div className="login-container">


        {/* =========================
            LEFT SIDE
        ========================= */}

        <div className="login-info">

          <div className="brand">

            🚀

            <span>
              GitBridge <b>AI</b>
            </span>

          </div>


          <h1>
            Build Your Career
            <br />
            With AI.
          </h1>


          <p>
            Analyze your GitHub profile, improve
            your resume and discover personalized
            career opportunities.
          </p>


          <div className="login-features">

            <div>
              <span>✓</span>
              AI-powered GitHub analysis
            </div>


            <div>
              <span>✓</span>
              Resume & ATS analysis
            </div>


            <div>
              <span>✓</span>
              Personalized job opportunities
            </div>


            <div>
              <span>✓</span>
              AI career roadmap
            </div>

          </div>

        </div>


        {/* =========================
            RIGHT SIDE
        ========================= */}

        <div className="login-card">


          {/* =========================
              LOGIN HEADING
          ========================= */}

          <div className="login-heading">

            <div className="login-logo">
              🚀
            </div>


            <h2>
              Welcome Back
            </h2>


            <p>
              Sign in to continue to GitBridge AI
            </p>

          </div>


          {/* =========================
              EMAIL LOGIN
          ========================= */}

          <form
            onSubmit={handleEmailLogin}
          >

            <label>
              Email Address
            </label>


            <input
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) =>
                setEmail(e.target.value)
              }
              disabled={loading}
            />


            <label>
              Password
            </label>


            <input
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) =>
                setPassword(e.target.value)
              }
              disabled={loading}
            />


            <button
              className="login-btn"
              type="submit"
              disabled={loading}
            >

              {loading
                ? "Signing in..."
                : "Sign In →"}

            </button>

          </form>


          {/* =========================
              DIVIDER
          ========================= */}

          <div className="divider">

            <span></span>

            <p>OR</p>

            <span></span>

          </div>


          {/* =========================
              GOOGLE LOGIN
          ========================= */}

          <button
            className="google-btn"
            onClick={handleGoogleLogin}
            disabled={loading}
          >

            <img
              src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/google/google-original.svg"
              alt="Google"
            />

            {loading
              ? "Signing in..."
              : "Continue with Google"}

          </button>


          {/* =========================
              SIGN UP
          ========================= */}

          <div className="signup-text">

            Don't have an account?


            <button
              onClick={() =>
                navigate("/signup")
              }
              disabled={loading}
            >
              Create Account
            </button>

          </div>


          {/* =========================
              SECURITY
          ========================= */}

          <p className="security-text">
            🔒 Your information is securely protected.
          </p>


        </div>

      </div>

    </div>

  );
};

export default LoginPage;