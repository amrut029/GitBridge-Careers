import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./SignupPage.css";

const SignUpPage = () => {

    const navigate = useNavigate();

    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const handleSignup = (e) => {

        e.preventDefault();

        if (!name || !email || !password) {
        alert("Please fill all fields.");
        return;
        }

        if (password.length < 6) {
        alert("Password must be at least 6 characters.");
        return;
        }

        // Temporary signup
        localStorage.setItem(
        "user",
        JSON.stringify({
            name,
            email
        })
        );

        navigate("/getstarted");
    };


    return (

        <div className="signup-page">

        {/* ================= LEFT ================= */}

        <section className="signup-form-section">

            <button
            className="back-login"
            onClick={() => navigate("/login")}
            >
            ← Back to Login
            </button>


            <div className="signup-card">

            <div className="signup-logo">
                🚀
            </div>


            <h1>
                Create Your
                <br />
                <span>GitBridge AI</span> Account
            </h1>

            <p className="signup-subtitle">
                Start your AI-powered career journey today.
            </p>


            <form onSubmit={handleSignup}>

                <label>Full Name</label>

                <input
                type="text"
                placeholder="Enter your full name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                />


                <label>Email Address</label>

                <input
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                />


                <label>Password</label>

                <input
                type="password"
                placeholder="Minimum 6 characters"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                minLength={6}
                required
                />


                <button
                className="create-account-btn"
                type="submit"
                >
                Create Account →
                </button>

            </form>


            <div className="login-link">

                Already have an account?

                <button
                onClick={() => navigate("/login")}
                >
                Sign In
                </button>

            </div>


            <div className="signup-security">
                🔒 Your account information is securely protected.
            </div>

            </div>

        </section>


        {/* ================= RIGHT ================= */}

        <section className="signup-info-section">

            <div className="signup-info">

            <div className="small-badge">
                ✦ AI-Powered Career Intelligence
            </div>


            <h2>
                Your Career.
                <br />
                <span>Powered by AI.</span>
            </h2>


            <p>
                GitBridge AI connects your GitHub profile
                and resume to understand your skills,
                measure your career readiness and help
                you discover better opportunities.
            </p>


            <div className="signup-features">

                <div className="feature-box">

                <div className="feature-icon">
                    🐙
                </div>

                <h3>
                    GitHub Analysis
                </h3>

                <p>
                    Analyze repositories, commits,
                    languages and projects.
                </p>

                </div>


                <div className="feature-box">

                <div className="feature-icon">
                    📄
                </div>

                <h3>
                    Resume Analysis
                </h3>

                <p>
                    Get ATS score, skill extraction
                    and personalized feedback.
                </p>

                </div>


                <div className="feature-box">

                <div className="feature-icon">
                    🎯
                </div>

                <h3>
                    Career Score
                </h3>

                <p>
                    Understand your strengths and
                    areas to improve.
                </p>

                </div>


                <div className="feature-box">

                <div className="feature-icon">
                    💼
                </div>

                <h3>
                    Job Matching
                </h3>

                <p>
                    Discover opportunities matching
                    your skills and profile.
                </p>

                </div>

            </div>

            </div>

        </section>

        </div>

    );
};

export default SignUpPage;