import React, { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./DashboardPage.css";

import {
  getGithubProfile,
  getGithubRepositories,
  getGithubPublicEvents,
  searchGithubCommits,
  searchGithubPullRequests,
  searchGithubIssues,
} from "../../Services/githubApi";

const clamp = (value, min = 0, max = 100) =>
  Math.min(Math.max(Number(value) || 0, min), max);

const calculateGithubScore = ({
  repositories,
  stars,
  forks,
  followers,
  languages,
  recentPushEvents,
  repositoriesWithDescription,
}) => {
  // No public repositories = 0. There is deliberately no default/baseline score.
  if (repositories === 0) return 0;

  const repoPoints = Math.min(repositories / 10, 1) * 25;
  const starPoints = Math.min(stars / 50, 1) * 15;
  const forkPoints = Math.min(forks / 20, 1) * 10;
  const followerPoints = Math.min(followers / 100, 1) * 10;
  const languagePoints = Math.min(languages / 5, 1) * 10;
  const activityPoints = Math.min(recentPushEvents / 20, 1) * 15;
  const documentationPoints =
    (repositoriesWithDescription / repositories) * 15;

  return Math.round(
    repoPoints +
      starPoints +
      forkPoints +
      followerPoints +
      languagePoints +
      activityPoints +
      documentationPoints
  );
};

const getScoreLabel = (score) => {
  if (score === 0) return "No public project data";
  if (score < 30) return "Beginner";
  if (score < 50) return "Developing";
  if (score < 70) return "Good";
  if (score < 85) return "Strong";
  return "Excellent";
};

const UserDashboard = () => {
  const navigate = useNavigate();

  const [github, setGithub] = useState("");
  const [resume, setResume] = useState(null);
  const [githubData, setGithubData] = useState(null);
  const [githubScore, setGithubScore] = useState(0);
  const [githubLoading, setGithubLoading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);

  const storedUser = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem("user") || "null");
    } catch {
      return null;
    }
  }, []);

  const displayName =
    storedUser?.displayName ||
    storedUser?.name ||
    storedUser?.email?.split("@")[0] ||
    "Developer";

  const repositories = githubData?.repositories || [];

  const totalStars = useMemo(
    () =>
      repositories.reduce(
        (sum, repo) => sum + Number(repo.stargazers_count || 0),
        0
      ),
    [repositories]
  );

  const totalForks = useMemo(
    () =>
      repositories.reduce(
        (sum, repo) => sum + Number(repo.forks_count || 0),
        0
      ),
    [repositories]
  );

  const totalOpenIssues = useMemo(
    () =>
      repositories.reduce(
        (sum, repo) => sum + Number(repo.open_issues_count || 0),
        0
      ),
    [repositories]
  );

  const languageStats = useMemo(() => {
    const counts = {};

    repositories.forEach((repo) => {
      if (repo.language) {
        counts[repo.language] = (counts[repo.language] || 0) + 1;
      }
    });

    const total = Object.values(counts).reduce((a, b) => a + b, 0);

    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .map(([name, count]) => ({
        name,
        count,
        percent: total ? Math.round((count / total) * 100) : 0,
      }));
  }, [repositories]);

  const topRepositories = useMemo(
    () =>
      [...repositories]
        .sort(
          (a, b) =>
            Number(b.stargazers_count || 0) +
            Number(b.forks_count || 0) -
            (Number(a.stargazers_count || 0) +
              Number(a.forks_count || 0))
        )
        .slice(0, 8),
    [repositories]
  );

  const handleGithub = async () => {
    const username = github.trim();

    if (!username) {
      alert("Please enter your GitHub username.");
      return;
    }

    try {
      setGithubLoading(true);

      const [profile, repos, events, commitSearch, prSearch, issueSearch] =
        await Promise.all([
          getGithubProfile(username),
          getGithubRepositories(username),
          getGithubPublicEvents(username),
          searchGithubCommits(username),
          searchGithubPullRequests(username),
          searchGithubIssues(username),
        ]);

      const recentPushEvents = Array.isArray(events)
        ? events.filter((event) => event.type === "PushEvent").length
        : 0;

      const commits =
        typeof commitSearch?.total_count === "number"
          ? commitSearch.total_count
          : null;

      const pullRequests =
        typeof prSearch?.total_count === "number"
          ? prSearch.total_count
          : null;

      const issuesCreated =
        typeof issueSearch?.total_count === "number"
          ? issueSearch.total_count
          : null;

      const repositoriesWithDescription = repos.filter(
        (repo) => String(repo.description || "").trim().length > 0
      ).length;

      const forkedRepositories = repos.filter((repo) => repo.fork).length;

      const data = {
        profile,
        repositories: repos,
        events,
        recentPushEvents,
        commits,
        pullRequests,
        issuesCreated,
        repositoriesWithDescription,
        forkedRepositories,
        totalStars: repos.reduce(
          (sum, repo) => sum + Number(repo.stargazers_count || 0),
          0
        ),
        totalForks: repos.reduce(
          (sum, repo) => sum + Number(repo.forks_count || 0),
          0
        ),
        languageStats: [],
      };

      const languageMap = {};
      repos.forEach((repo) => {
        if (repo.language) {
          languageMap[repo.language] = (languageMap[repo.language] || 0) + 1;
        }
      });

      const languageTotal = Object.values(languageMap).reduce(
        (a, b) => a + b,
        0
      );

      data.languageStats = Object.entries(languageMap)
        .sort((a, b) => b[1] - a[1])
        .map(([name, count]) => ({
          name,
          count,
          percent: languageTotal
            ? Math.round((count / languageTotal) * 100)
            : 0,
        }));

      const score = calculateGithubScore({
        repositories: repos.length,
        stars: data.totalStars,
        forks: data.totalForks,
        followers: Number(profile.followers || 0),
        languages: data.languageStats.length,
        recentPushEvents,
        repositoriesWithDescription,
      });

      setGithubData(data);
      setGithubScore(score);
    } catch (error) {
      console.error(error);
      alert(
        error.message ||
          "Unable to load this GitHub profile. Please check the username."
      );
    } finally {
      setGithubLoading(false);
    }
  };

  const handleResume = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      alert("Resume must be smaller than 5MB.");
      return;
    }

    const allowedTypes = [
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ];

    if (!allowedTypes.includes(file.type)) {
      alert("Please upload a PDF or DOC/DOCX file.");
      return;
    }

    setResume(file);
  };

  const startAnalysis = () => {
    if (!githubData) {
      alert("Connect GitHub first.");
      return;
    }

    if (!resume) {
      alert("Upload your resume first.");
      return;
    }

    // This is intentionally only the UI state for now.
    // Resume scoring must come from the Python backend, not a fake number.
    setAnalyzing(true);

    setTimeout(() => {
      setAnalyzing(false);
      alert(
        "GitHub analysis is real. Resume/overall career scoring will be enabled after the Python resume-analysis API is connected."
      );
    }, 1000);
  };

  return (
    <div className="dashboard">
      <aside className="sidebar">
        <div className="logo">
          🎓 <span>GitBridge <b>AI</b></span>
        </div>

        <nav>
          <button
            className="nav-item active"
            onClick={() => navigate("/dashboard")}
          >
            ⌂ <span>Overview</span>
          </button>

          <button
            className="nav-item"
            onClick={() => navigate("/dashboard")}
          >
            ▦ <span>Dashboard</span>
          </button>

          <button
            className="nav-item"
            onClick={() =>
              document
                .querySelector(".github-profile-card")
                ?.scrollIntoView({ behavior: "smooth" })
            }
          >
            ◉ <span>GitHub Analysis</span>
          </button>

          <button
            className="nav-item"
            onClick={() =>
              document
                .querySelector(".resume-card")
                ?.scrollIntoView({ behavior: "smooth" })
            }
          >
            ▤ <span>Resume Review</span>
          </button>

          <button
            className="nav-item"
            onClick={() =>
              document
                .querySelector(".github-metrics")
                ?.scrollIntoView({ behavior: "smooth" })
            }
          >
            💼 <span>Opportunities</span>
          </button>

          <button
            className="nav-item"
            onClick={() =>
              document
                .querySelector(".language-section")
                ?.scrollIntoView({ behavior: "smooth" })
            }
          >
            ◎ <span>Skill Gap</span>
          </button>

          <button className="nav-item">
            ♧ <span>Roadmap</span>
          </button>

          <button className="nav-item">
            ↗ <span>Progress</span>
          </button>

          <button className="nav-item">
            ♡ <span>Bookmarks</span>
          </button>

          <button className="nav-item">
            ⚙ <span>Settings</span>
          </button>
        </nav>

        <div className="profile-box">
          <h3>Unlock Full Potential 👑</h3>
          <p>
            Complete your profile to get AI insights and personalized
            recommendations.
          </p>
          <button onClick={() => navigate("/getstarted")}>
            Complete Profile →
          </button>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="topbar-title">Career Intelligence</div>

          <div className="user">
            <span className="notification">🔔</span>
            <div className="avatar">
              {displayName.charAt(0).toUpperCase()}
            </div>
            <span>{displayName}</span>
            <span>⌄</span>
          </div>
        </header>

        <section className="content">
          <div className="welcome">
            <div>
              <div className="eyebrow">AI CAREER INTELLIGENCE</div>
              <h1>Welcome, {displayName}! 👋</h1>
              <p>
                Connect your GitHub and see a complete, data-driven profile
                instead of placeholder numbers.
              </p>
            </div>

            <div className="ai-icon">🤖</div>
          </div>

          <div className="setup-grid">
            <div className="setup-card github-card">
              <div className="big-icon">◉</div>
              <h2>Connect Your GitHub</h2>
              <p>
                Load your real public profile, repositories, stars, forks,
                languages, activity, issues and pull requests.
              </p>

              <div className="input-group">
                <input
                  type="text"
                  placeholder="GitHub Username"
                  value={github}
                  onChange={(e) => setGithub(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") handleGithub();
                  }}
                />

                <button onClick={handleGithub} disabled={githubLoading}>
                  {githubLoading ? "Loading..." : "Connect GitHub"}
                </button>
              </div>

              {githubData && (
                <div className="github-success">
                  <strong>✓ Connected</strong>
                  <span>@{githubData.profile.login}</span>
                  <span>Real Score: {githubScore}/100</span>
                </div>
              )}

              <div className="features-list">
                <span>✓ Repository analysis</span>
                <span>✓ Stars & forks</span>
                <span>✓ Language analysis</span>
                <span>✓ Public activity</span>
              </div>
            </div>

            <div className="setup-card resume-card">
              <div className="big-icon green">📄</div>
              <h2>Upload Your Resume</h2>
              <p>
                Upload a PDF/DOC/DOCX. The file is accepted here, but the
                actual ATS score will be calculated by your Python backend.
              </p>

              <label className="upload-box">
                <div className="upload-icon">⬆</div>
                <strong>
                  {resume ? resume.name : "Choose your resume"}
                </strong>
                <small>PDF, DOCX (Max 5MB)</small>

                <input
                  type="file"
                  accept=".pdf,.doc,.docx"
                  onChange={handleResume}
                />
              </label>

              <div className="features-list">
                <span>✓ ATS analysis</span>
                <span>✓ Skills extraction</span>
                <span>✓ Experience analysis</span>
                <span>✓ AI feedback</span>
              </div>
            </div>
          </div>

          <div className="analysis-section">
            <div>
              <h2>AI Career Analysis ✨</h2>
              <p>
                GitHub metrics are live. Start the combined analysis only
                after the Python resume-analysis endpoint is connected.
              </p>
            </div>

            <button
              className="analyze-btn"
              onClick={startAnalysis}
              disabled={analyzing}
            >
              {analyzing ? "Checking..." : "Start AI Analysis →"}
            </button>
          </div>

          {githubData && (
            <div className="results">
              <div className="results-heading detailed-heading">
                <div>
                  <div className="eyebrow">LIVE GITHUB PROFILE ANALYTICS</div>
                  <h2>Your GitHub Dashboard 🎉</h2>
                  <p>
                    Real public data for @{githubData.profile.login}. No
                    default score is added when data is missing.
                  </p>
                </div>

                <div className="score-summary">
                  <span>GitHub Score</span>
                  <strong>{githubScore}/100</strong>
                  <small>{getScoreLabel(githubScore)}</small>
                </div>
              </div>

              <div className="github-profile-card">
                <div className="github-profile-main">
                  <img
                    className="github-avatar"
                    src={githubData.profile.avatar_url}
                    alt={githubData.profile.login}
                  />

                  <div className="github-profile-info">
                    <div className="profile-title-row">
                      <div>
                        <h2>
                          {githubData.profile.name ||
                            githubData.profile.login}
                        </h2>
                        <span>@{githubData.profile.login}</span>
                      </div>

                      <a
                        href={githubData.profile.html_url}
                        target="_blank"
                        rel="noreferrer"
                        className="github-profile-btn"
                      >
                        View GitHub ↗
                      </a>
                    </div>

                    <p className="profile-bio">
                      {githubData.profile.bio ||
                        "No GitHub bio added yet."}
                    </p>

                    <div className="profile-meta">
                      {githubData.profile.location && (
                        <span>📍 {githubData.profile.location}</span>
                      )}
                      {githubData.profile.company && (
                        <span>🏢 {githubData.profile.company}</span>
                      )}
                      {githubData.profile.blog && (
                        <span>🔗 {githubData.profile.blog}</span>
                      )}
                      {githubData.profile.twitter_username && (
                        <span>
                          𝕏 @{githubData.profile.twitter_username}
                        </span>
                      )}
                      {githubData.profile.created_at && (
                        <span>
                          📅 Joined{" "}
                          {new Date(
                            githubData.profile.created_at
                          ).toLocaleDateString()}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="profile-stat-grid">
                  <MiniStat
                    value={githubData.profile.followers ?? 0}
                    label="Followers"
                  />
                  <MiniStat
                    value={githubData.profile.following ?? 0}
                    label="Following"
                  />
                  <MiniStat
                    value={githubData.profile.public_repos ?? repositories.length}
                    label="Public Repos"
                  />
                  <MiniStat
                    value={githubData.profile.public_gists ?? 0}
                    label="Public Gists"
                  />
                  <MiniStat value={totalStars} label="Total Stars" />
                  <MiniStat value={totalForks} label="Total Forks" />
                </div>
              </div>

              <div className="score-grid">
                <Score
                  title="GitHub Score"
                  score={githubScore}
                  type="green"
                  status={getScoreLabel(githubScore)}
                />
                <Score
                  title="Resume Score"
                  score="—"
                  type="blue"
                  status="Not analyzed"
                />
                <Score
                  title="Skill Match"
                  score="—"
                  type="orange"
                  status="Not analyzed"
                />
                <Score
                  title="Career Score"
                  score="—"
                  type="purple"
                  status="Needs resume analysis"
                />
              </div>

              <div className="section-title-row github-metrics">
                <div>
                  <h2>GitHub Overview 📊</h2>
                  <p>Values below come from the connected public profile.</p>
                </div>
              </div>

              <div className="metric-grid">
                <MetricCard
                  icon="📦"
                  value={repositories.length}
                  label="Public Repositories"
                  detail="Repositories loaded"
                />
                <MetricCard
                  icon="⭐"
                  value={totalStars}
                  label="Total Stars"
                  detail="Across repositories"
                />
                <MetricCard
                  icon="🍴"
                  value={totalForks}
                  label="Total Forks"
                  detail="Across repositories"
                />
                <MetricCard
                  icon="👥"
                  value={githubData.profile.followers ?? 0}
                  label="Followers"
                  detail="GitHub followers"
                />
                <MetricCard
                  icon="👤"
                  value={githubData.profile.following ?? 0}
                  label="Following"
                  detail="Accounts followed"
                />
                <MetricCard
                  icon="💻"
                  value={languageStats.length}
                  label="Languages"
                  detail="Primary languages detected"
                />
                <MetricCard
                  icon="⚡"
                  value={githubData.recentPushEvents}
                  label="Recent Push Events"
                  detail="From latest public events"
                />
                <MetricCard
                  icon="🔀"
                  value={
                    githubData.pullRequests == null
                      ? "—"
                      : githubData.pullRequests
                  }
                  label="Pull Requests"
                  detail="GitHub search result"
                />
                <MetricCard
                  icon="🐛"
                  value={
                    githubData.issuesCreated == null
                      ? "—"
                      : githubData.issuesCreated
                  }
                  label="Issues Created"
                  detail="GitHub search result"
                />
                <MetricCard
                  icon="📝"
                  value={
                    githubData.commits == null ? "—" : githubData.commits
                  }
                  label="Commits Found"
                  detail="GitHub commit search"
                />
                <MetricCard
                  icon="📄"
                  value={githubData.repositoriesWithDescription}
                  label="Documented Projects"
                  detail="Repositories with description"
                />
                <MetricCard
                  icon="🔱"
                  value={githubData.forkedRepositories}
                  label="Forked Repositories"
                  detail="Forks among loaded repos"
                />
              </div>

              <div className="detail-grid-two language-section">
                <div className="result-card">
                  <div className="card-heading">
                    <div>
                      <h3>💻 Languages & Technologies</h3>
                      <p>
                        Based on the primary language reported by each public
                        repository.
                      </p>
                    </div>
                  </div>

                  {languageStats.length ? (
                    languageStats.map((item) => (
                      <div className="language-row" key={item.name}>
                        <div className="language-label">
                          <span>{item.name}</span>
                          <b>{item.count} projects</b>
                        </div>
                        <div className="language-bar">
                          <div style={{ width: `${item.percent}%` }} />
                        </div>
                        <small>{item.percent}% of language-tagged projects</small>
                      </div>
                    ))
                  ) : (
                    <div className="empty-state">
                      No programming languages detected because this account
                      has no public repositories with a detected primary
                      language.
                    </div>
                  )}
                </div>

                <div className="result-card">
                  <div className="card-heading">
                    <div>
                      <h3>⭐ Top Repository Performance</h3>
                      <p>Sorted by stars + forks.</p>
                    </div>
                  </div>

                  {topRepositories.length ? (
                    topRepositories.map((repo) => (
                      <div className="repo-mini-row" key={repo.id}>
                        <div>
                          <a
                            href={repo.html_url}
                            target="_blank"
                            rel="noreferrer"
                          >
                            <strong>{repo.name}</strong>
                          </a>
                          <small>
                            {repo.language || "No primary language"} ·{" "}
                            {repo.private ? "Private" : "Public"}
                          </small>
                        </div>
                        <div className="repo-mini-stats">
                          <span>⭐ {repo.stargazers_count || 0}</span>
                          <span>🍴 {repo.forks_count || 0}</span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="empty-state">
                      No public repositories found.
                    </div>
                  )}
                </div>
              </div>

              <div className="repositories-card">
                <div className="section-title-row">
                  <div>
                    <h2>All Projects & Repositories 🚀</h2>
                    <p>
                      Repository-level information returned by GitHub.
                    </p>
                  </div>
                  <span className="repo-count">
                    {repositories.length} loaded
                  </span>
                </div>

                {repositories.length ? (
                  <div className="repository-table-wrap">
                    <table className="repository-table">
                      <thead>
                        <tr>
                          <th>Project</th>
                          <th>Language</th>
                          <th>Stars</th>
                          <th>Forks</th>
                          <th>Issues</th>
                          <th>Size</th>
                          <th>Updated</th>
                        </tr>
                      </thead>
                      <tbody>
                        {repositories.map((repo) => (
                          <tr key={repo.id}>
                            <td>
                              <a
                                href={repo.html_url}
                                target="_blank"
                                rel="noreferrer"
                              >
                                <strong>{repo.name}</strong>
                              </a>
                              <small>
                                {repo.description ||
                                  "No description available."}
                              </small>
                            </td>
                            <td>
                              <span className="language-pill">
                                {repo.language || "—"}
                              </span>
                            </td>
                            <td>⭐ {repo.stargazers_count || 0}</td>
                            <td>🍴 {repo.forks_count || 0}</td>
                            <td>{repo.open_issues_count || 0}</td>
                            <td>{repo.size || 0} KB</td>
                            <td>
                              {repo.updated_at
                                ? new Date(
                                    repo.updated_at
                                  ).toLocaleDateString()
                                : "—"}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="empty-projects">
                    <div className="empty-project-icon">📦</div>
                    <h3>No public projects</h3>
                    <p>
                      This GitHub account currently has 0 public repositories.
                      GitBridge correctly gives a GitHub score of 0/100 instead
                      of inventing a baseline score.
                    </p>
                  </div>
                )}
              </div>

              <div className="repository-detail-grid">
                {repositories.slice(0, 8).map((repo) => (
                  <div className="repository-detail-card" key={repo.id}>
                    <div className="repo-card-top">
                      <div>
                        <span className="repo-icon">📁</span>
                        <h3>{repo.name}</h3>
                      </div>
                      <span className="repo-visibility">
                        {repo.private ? "Private" : "Public"}
                      </span>
                    </div>

                    <p>
                      {repo.description ||
                        "No description available for this project."}
                    </p>

                    <div className="repo-topic-list">
                      {(repo.topics || []).slice(0, 6).map((topic) => (
                        <span key={topic}>{topic}</span>
                      ))}
                    </div>

                    <div className="repo-detail-stats">
                      <span>💻 {repo.language || "No language"}</span>
                      <span>⭐ {repo.stargazers_count || 0}</span>
                      <span>🍴 {repo.forks_count || 0}</span>
                      <span>🐛 {repo.open_issues_count || 0}</span>
                      <span>📦 {repo.size || 0} KB</span>
                    </div>

                    <div className="repo-card-footer">
                      <span>
                        Created{" "}
                        {repo.created_at
                          ? new Date(repo.created_at).toLocaleDateString()
                          : "—"}
                      </span>
                      <a
                        href={repo.html_url}
                        target="_blank"
                        rel="noreferrer"
                      >
                        Open Project ↗
                      </a>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bottom-grid">
                <div className="result-card">
                  <h3>📊 Activity Snapshot</h3>
                  <p>⚡ Recent push events: {githubData.recentPushEvents}</p>
                  <p>
                    📝 Commits found:{" "}
                    {githubData.commits == null
                      ? "Unavailable"
                      : githubData.commits}
                  </p>
                  <p>
                    🔀 Pull requests:{" "}
                    {githubData.pullRequests == null
                      ? "Unavailable"
                      : githubData.pullRequests}
                  </p>
                  <p>
                    💬 Issues created:{" "}
                    {githubData.issuesCreated == null
                      ? "Unavailable"
                      : githubData.issuesCreated}
                  </p>
                  <p>🐛 Open repository issues: {totalOpenIssues}</p>
                </div>

                <div className="result-card">
                  <h3>🎯 GitHub Score Formula</h3>
                  <p>Repositories: 25 points</p>
                  <p>Stars: 15 points</p>
                  <p>Forks: 10 points</p>
                  <p>Followers: 10 points</p>
                  <p>Languages: 10 points</p>
                  <p>Recent public activity: 15 points</p>
                  <p>Documented projects: 15 points</p>
                  <strong className="formula-total">
                    Total = {githubScore}/100
                  </strong>
                </div>

                <div className="result-card">
                  <h3>⚠️ Data Notes</h3>
                  <p>
                    GitHub profile, repositories, stars, forks and repository
                    metadata are read directly from GitHub's public API.
                  </p>
                  <p>
                    Commit/PR/issue totals use GitHub Search API and can be
                    unavailable when GitHub rate-limits an unauthenticated
                    request.
                  </p>
                  <p>
                    Resume and career scores stay blank until the Python
                    analysis API returns a real result.
                  </p>
                </div>
              </div>
            </div>
          )}
        </section>
      </main>
    </div>
  );
};

const MiniStat = ({ value, label }) => (
  <div className="profile-stat">
    <strong>{value}</strong>
    <span>{label}</span>
  </div>
);

const MetricCard = ({ icon, value, label, detail }) => (
  <div className="metric-card">
    <div className="metric-icon">{icon}</div>
    <div>
      <strong>{value}</strong>
      <span>{label}</span>
      <small>{detail}</small>
    </div>
  </div>
);

const Score = ({ title, score, type, status }) => {
  const numericScore = Number(score);
  const isNumber = Number.isFinite(numericScore);

  return (
    <div className="score-card">
      <h3>{title}</h3>
      <div className={`circle ${type}`}>
        <strong>{score}</strong>
        {isNumber && <small>/100</small>}
      </div>
      <b className={`status ${type}`}>{status}</b>
      <p>
        {title === "GitHub Score"
          ? "Calculated from live public GitHub metrics"
          : "Not calculated yet"}
      </p>
    </div>
  );
};

export default UserDashboard;